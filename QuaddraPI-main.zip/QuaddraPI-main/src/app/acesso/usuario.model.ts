export class Usuario{

    constructor(
        public email:string,
        public nome_completo:string,
        public telefone:string,        
        public senha:string
    ){}

}